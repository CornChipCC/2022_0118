from django.apps import AppConfig


class ThirdappConfig(AppConfig):
    name = 'thirdapp'
